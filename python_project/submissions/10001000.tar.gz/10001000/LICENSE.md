
(C) University College London 2014

This "greetings" example package is granted into the public domain.