
Greetings!
==========

This is a very simple example package used as part of the UCL
[Research Software Engineering with Python](development.rc.ucl.ac.uk/training/engineering) course.

Usage:
    
Invoke the tool with `greet <FirstName> <Secondname>`
